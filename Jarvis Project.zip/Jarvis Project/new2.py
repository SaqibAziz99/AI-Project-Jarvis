import json 
import numpy as np
from tensorflow import keras
from sklearn.preprocessing import LabelEncoder

import colorama 
colorama.init()
from colorama import Fore, Style, Back

import random
import pickle
# jarvis
import  pyttsx3
import datetime
import speech_recognition as sr
import wikipedia
import os
import webbrowser
import smtplib
from pywikihow import search_wikihow
from playsound import playsound



engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
# print(voices[0].id)
engine.setProperty('voice',voices[0].id)

def speak(audio):
    engine.say(audio)
    engine.runAndWait()

def wishMe():
    hour = int(datetime.datetime.now().hour)
    if hour>=0 and hour<12:
        speak("Good Morning, boss")
    elif hour>=12 and hour<18:
        speak("Good Afternoon, boss")
    else:
        speak("Good Evening, boss")
    speak("How can I help you!!")
    

def sendEmail(to, content):
    server = smtplib.SMTP('smtp.mail.yahoo.com', 587)
    server.ehlo()
    server.starttls()
    server.login('arana852@yahoo.com', 'zeacfnsdbmlidbqd')
    server.sendmail('arana852@yahoo.com', to, "\n"+content)
    server.close()


def GoogleSearch(text):
    search = "https://www.google.com/search?q="+text 
    webbrowser.open(search)
    speak("This is what I found for you")
    
def takeCommand():
    
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source)
    try:
        print("Recognizing...")    
        query = r.recognize_google(audio, language='en-in') #Using google for voice recognition.
        print(f"User said: {query}\n")  #User query will be printed.
    except Exception as e:
        # print(e)    
        print("Say that again please...")  
        return "None" #None string will be returned
    return query
    

with open("intents.json") as file:
    data = json.load(file)

def youtubeSearch(text):
    search = "https://www.youtube.com/results?search_query="+text
    webbrowser.open(search)
    speak("This is what I found for you")
    
def wishMe():
    hour = int(datetime.datetime.now().hour)
    if hour>=0 and hour<12:
        speak("Good Morning, boss")
    elif hour>=12 and hour<18:
        speak("Good Afternoon, boss")
    else:
        speak("Good Evening, boss")
    speak("How can I help you!!")

def chat():
    # load trained model
    model = keras.models.load_model('chat_model')

    # load tokenizer object
    with open('tokenizer.pickle', 'rb') as handle:
        tokenizer = pickle.load(handle)

    # load label encoder object
    with open('label_encoder.pickle', 'rb') as enc:
        lbl_encoder = pickle.load(enc)

    # parameters
    max_len = 20
    
    wishMe()
    
    while True:
        print(Fore.LIGHTBLUE_EX + "User: " + Style.RESET_ALL, end="")
        inp = takeCommand().lower()
        
        if 'open youtube' in inp:
             speak("what should I search on youtube?")
             search = takeCommand().lower()
             youtubeSearch(search)
             break
         
        elif 'open google' in inp:
            speak("what should I search on Google?")
            search = takeCommand().lower()
            GoogleSearch(search)
            break
            
        elif 'open stackoverflow' in inp or 'error' in inp:
            speak("let me open stackoverflow for you")
            
            webbrowser.open("stackoverflow.com")
        # C:\Users\hi\Documents
        
        
        elif 'how to' in inp:
            how_to = search_wikihow(query=inp, max_results=1)
            assert len(how_to) ==1
            how_to[0].print()
            
            speak(how_to[0].summary)
        
        elif 'alarm' in inp:
            speak("Please Enter the Time !")
            
            time = input(": Time :")
            
            while True:
                Time_Ac = datetime.datetime.now()
                now = Time_Ac.strftime("%H:%M:%S")
                
                # print("Time is:", now)
                if now==time:
                    speak("Time To Wake Up Sir!")
                    playsound('ring2.mp3')
                    speak("Alarm Closed!")
                elif now>time:
                    speak("Alarm time has exceeded current time")
                    break
         
            
        elif 'play music' in inp:
            music_dir = 'C:\\Users\\hi\\Documents//songs'
            songs = os.listdir(music_dir)
            
            os.startfile(os.path.join(music_dir, songs[0]))
            break
        
        elif 'the time' in inp:
            strTime = datetime.datetime.now()
            now = strTime.strftime("%H:%M:%S")    
            speak(f"Sir, the time is {now}")
            
        
        elif 'wikipedia' in inp:
            speak('Searching Wikipedia...')
            inp = inp.replace("wikipedia", "")
            results = wikipedia.summary(inp, sentences=2) 
            speak("According to Wikipedia")
            print(results)
            
            speak(results)
            
        elif 'send an email' in inp:
            try:
                speak("Please Input Reciever's email")
                to = input("Email:")
                speak("What should I say?")
                content = takeCommand()   
                sendEmail(to, content)
                print(content)
                speak("Email has been sent!")
                
            except Exception as e:
                print(e)
                speak("Sorry, I was not able to send this email")
        
        elif 'goodbye' in inp:
            speak('Goodbye sir...')
            break
        
        else:
            test_num = 0
            result = model.predict(keras.preprocessing.sequence.pad_sequences(tokenizer.texts_to_sequences([inp]),
                                             truncating='post', maxlen=max_len))
            tag = lbl_encoder.inverse_transform([np.argmax(result)])
            
            for i in data['intents']:
                if i['tag'] == tag:
                    test_num = test_num + 1
                    speak(np.random.choice(i['responses']))
            
            if test_num ==0:
                speak("Sorry sir, I could not understand what you just said. Please Repeat yourself")
                continue
        speak("what else can I do for you?")
            
chat()